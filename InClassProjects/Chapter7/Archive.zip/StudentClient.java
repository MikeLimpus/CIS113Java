public class StudentClient {
    public static void main(String args[]) {
        Student studentObject1 = new Student();
        System.out.print("Student 1: " + studentObject1.getStudentName() + " " /*etc etc etc*/);

        Student studentObject2 = new Student();
        Student studentObject3 = new Student();

    }
}