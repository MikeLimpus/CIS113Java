import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CounterPanel extends JPanel {

	// *****************************
	// Declare GUI objects
	// *****************************
	
	private JButton increase, decrease;
	private JLabel labelNumber, labelInput;
	private JPanel panelValue, panelStyle, panelColor;
	
	private JTextField inputNumber;
	
	private JCheckBox bold, italic;
	private JRadioButton red, green, blue;
	
	private int counter;
	
	public CounterPanel()
	{
		counter = 0;
		
		// ******************************
		// Define buttons and text inputs
		// ******************************
		
		increase = new JButton("increase");
		decrease = new JButton("decrease");
		
		ButtonListener listener = new ButtonListener();
		increase.addActionListener(listener);
		decrease.addActionListener(listener);
		
		inputNumber = new JTextField(5); // number is the limit of input characters
		inputNumber.addKeyListener(new InputListener());
		
		labelNumber = new JLabel("Counter Value:" + counter);
		labelNumber.setFont(new Font("Helvetica", Font.PLAIN, 12));
		labelNumber.setForeground(Color.white);
		
		labelInput = new JLabel("Please Enter a Number");
		labelInput.setFont(new Font("Helvetica", Font.PLAIN, 12));
		labelInput.setForeground(Color.white);
		
		panelValue = new JPanel();
		panelValue.setPreferredSize(new Dimension(200, 60));	// Horizontal, Vertical 
		panelValue.setBackground(Color.blue);
		
		panelValue.add(increase);
		panelValue.add(decrease);
		panelValue.add(labelInput);
		panelValue.add(labelNumber);
		
		// ******************************
		// Define check boxes 
		// ******************************
		
		bold = new JCheckBox("BOLD");
		bold.setBackground(Color.green);
		italic = new JCheckBox("italic");
		italic.setBackground(Color.green);

		StyleListener cdListener = new StyleListener();
		bold.addItemListener(cbListener);
		italic.addItemListener(cbListener);

		panelStyle = new JPanel();
		panelStyle.setPreferredSize(new Dimnesion(200, 40));
		panelStyle.setBackground(Color.green);

		panelStyle.add(bold);
		panelStyle.add(italic);

		// Define Radio Buttons 

		red = new JRadioButton("Red");
		red.setBackground(Color.yellow);
		green = new JRadioButton("green");
		red.setBackground(Color.yellow);
		blue = new JRadioButton("Blue");
		blue.setBackground(Color.yellow);

		ButtonGroup colorGroup = new ButtonGroup();
		colorGroup.add(red);
		colorGroup.add(green);
		colorGroup.add(blue);

		ColorListener rbListener = new ColorListener();
		red.addActionListener(rbListener);
		green.addActionListener(rbListener);
		blue.addActionListener(rbListener);

		panelColor = new JPanel();

		panelColor.setPreferredSize(new Dimension(200, 40));
		panelColor.setBackground(Color.yellow);

		panelColor.add(red);
		panelColor.add(green);
		panelColor.add(blue);

		// Establish final frame options
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.black);
		add(labelNumber);
		add(panelStyle);
		add(panelColor);

	}
	// Action Listeners (Interactivity)

	// ButtonListener	
	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == increase) 
				counter++;
			else
				counter--;
			
				labelNumber.setText("Counter Value: " + counter);

		
		}
	}
	// Textbox Listener
	private class InputListener implements ActionListener {
		public void actionPerformed (ActionEvent event) {
			String text = inputNumber.getText();
			counter = Integer.parseInt(text);
			labelNumber.setText("Counter Value: " + counter);
		}
	}

	// Checkbox Listener 
	private class StyleListener implements ActionListener {
		public void itemStateChanged(ItemEvent event) {
			int style = Font.PLAIN;

			if(bold.isSelected())
				style += Font.BOLD;
			if(italic.isSelected())
				style += Font.ITALIC;

			labelNumber.setFont(new Font("Helvetica", style, 12));
			
		}
	}
	// Radio Button Listener
	private class ColorListener implements ActionListener {
		public void actionPerformed (ActionEvent event) {
			Object source = event.getSource();

			if(source == red) 
				labelNumber.setForeground(Color.red);
			if(source == green)
				labelNumber.setForeground(Color.green);
			if(source == blue)
				labelNumber.setForeground(Color.blue);
		}
	}

}
