import javax.swing.JFrame; //.JFrame is the window 

public class GUIdriver {

	public static void main(String[] args) {
		
		// create a frame object
		JFrame frame = new JFrame("THIS IS A WINDOW");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Add a custom panel to the frame 
		frame.getContentPane().add(new CounterPanel());
		
		// The following will scale the frame to its contents
		frame.pack();
		
		// Display the frame 
		frame.setVisible(true);
	}

}
